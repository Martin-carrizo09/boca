function PiePagina() {
  return (
    <footer className="bg-light text-center py-4 mt-5">
      <div className="container">
        <small>&copy; 2025 UTNFC ISI DDS. Material de trabajo en clase.</small>
      </div>
    </footer>
  );
}

export default PiePagina;