import { DataTypes, Model } from "sequelize";
import sequelize from "../db.js";
import Plataforma from "./plataforma.js";

class Juego extends Model {}

Juego.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      field: "ID_JUEGO"
    },
    nombre: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      field: "NOMBRE"
    },
    fechaEstreno: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: "FECHA_ESTRENO"
    },
    urlWeb: {
      type: DataTypes.STRING,
      allowNull: false,
      field: "URL_WEB"
    },
    genero: {
      type: DataTypes.STRING,
      allowNull: false,
      field: "GENERO"
    },
    dearrollador: { // Ojo: typo igual que en la base y en los repositorios
      type: DataTypes.STRING,
      allowNull: false,
      field: "DEARROLLADOR"
    },
    valoracion: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: { min: 0, max: 100 },
      field: "VALORACION"
    },
    opiniones: {
      type: DataTypes.INTEGER,
      allowNull: false,
      field: "OPINIONES"
    },
    idPlataforma: {
      type: DataTypes.INTEGER,
      allowNull: false,
      field: "ID_PLATAFORMA",
      references: {
        model: "PLATAFORMAS",
        key: "ID_PLATAFORMA"
      }
    }
  },
  {
    sequelize,
    modelName: "Juego",
    tableName: "INFO_JUEGOS",
    timestamps: false
  }
);

// Relación: cada juego pertenece a una plataforma
Juego.belongsTo(Plataforma, {
  foreignKey: "idPlataforma",
  as: "plataforma"
});

export default Juego;