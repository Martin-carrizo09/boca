import RepositorioBase from "./baseRepository.js";
import Plataforma from "../models/plataforma.js"; // Ensure this path is correct and plataforma.js exports Plataforma as default

class PlataformaRepository extends RepositorioBase {
  constructor() {
    super(Plataforma);
  }

  async obtenerTodos() {
    return this.modelo.findAll({
      order: [["NOMBRE", "ASC"]]
    });
  }
}

export default new PlataformaRepository();
    